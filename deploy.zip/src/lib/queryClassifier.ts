/**
 * Query Classifier
 * LLM-based classification of aviation regulatory questions
 * Routes queries to appropriate data sources (eCFR, DRS)
 */

import Anthropic from "@anthropic-ai/sdk";

/**
 * Classification result for a query
 */
export interface QueryClassification {
  // Query intent
  intent: 'regulatory_lookup' | 'compliance_guidance' | 'document_request' | 'general_question';
  
  // Detected aviation topics
  topics: string[];
  
  // CFR routing (for eCFR API)
  cfrParts: number[];
  cfrSections: string[];
  
  // Document routing (for DRS API)
  documentTypes: ('AC' | 'AD' | 'TSO' | 'Order')[];
  specificDocument?: string;
  
  // Confidence and reasoning
  confidence: number;
  reasoning: string;
  
  // Clarity assessment (for multi-turn conversations)
  needsClarification: boolean;
  clarificationReason?: string;
  suggestedQuestion?: string;
}

/**
 * Default classification for fallback scenarios
 */
const DEFAULT_CLASSIFICATION: QueryClassification = {
  intent: 'general_question',
  topics: [],
  cfrParts: [],
  cfrSections: [],
  documentTypes: ['AC'],
  confidence: 0.3,
  reasoning: 'Default classification - unable to determine specific routing',
  needsClarification: false
};

/**
 * System prompt for the classifier
 */
const CLASSIFIER_SYSTEM_PROMPT = `You are an FAA regulatory classification expert. Analyze aviation questions and identify:

1. The user's intent:
   - regulatory_lookup: Looking for specific regulation text
   - compliance_guidance: How to comply with requirements
   - document_request: Asking about a specific document (AC, AD, etc.)
   - general_question: General aviation question

2. Relevant 14 CFR Part numbers:
   - Part 21: Certification procedures (type certificates, production approvals)
   - Part 23: Normal category airplanes (23.2xxx = performance & flight characteristics)
   - Part 25: Transport category airplanes
   - Part 27: Normal category rotorcraft
   - Part 29: Transport category rotorcraft
   - Part 33: Aircraft engines
   - Part 35: Propellers
   - Part 39: Airworthiness directives
   - Part 43: Maintenance, preventive maintenance, alterations
   - Part 91: General operating rules
   - Part 121: Air carrier operations
   - Part 135: Commuter operations

   IMPORTANT: If the user does NOT specify an aircraft category, include BOTH Part 23 AND Part 25 for airplane airworthiness topics (bird strike, structural, performance, systems, etc.). Most topics have parallel requirements in both parts.

3. Specific CFR section numbers if determinable (e.g., "23.2150" for stall speed)
   - Include sections from ALL applicable parts (e.g., both 23.2240 AND 25.631 for bird strike)

4. Related document types:
   - AC: Advisory Circulars (compliance guidance)
   - AD: Airworthiness Directives (mandatory actions)
   - TSO: Technical Standard Orders
   - Order: FAA Orders

5. Query clarity assessment:
   - needsClarification: true if the query is too vague or broad to answer effectively
   - Vague queries: "tell me about regulations", "what are the rules", "help me with certification"
   - Broad queries: "Part 23 requirements" (which aspect?), "aircraft maintenance" (what type?)
   - Clear queries: "stall speed requirements for Part 23", "AC 43.13-1B content"
   - NOT vague: topic-specific questions like "bird strike testing" - return both Part 23 AND Part 25
   - If unclear, suggest a clarifying question to ask the user

Common section mappings (include BOTH when aircraft type not specified):
- Stall speed → § 23.2150 AND § 25.103
- Takeoff performance → § 23.2115 AND § 25.105
- Landing performance → § 23.2125 AND § 25.125
- Structural strength → § 23.2235 AND § 25.301
- Structural durability (includes bird strike, fatigue) → § 23.2240 AND § 25.571
- Bird strike damage → § 23.2240 (durability) AND § 25.631 (bird strike damage)
- Flutter/aeroelasticity → § 23.2245 AND § 25.629
- Fire protection → § 23.2325 AND § 25.1181-1207
- Fuel system → § 23.2430 AND § 25.951-1001
- Electrical → § 23.2500-2550 AND § 25.1351-1365

Respond ONLY with valid JSON matching the exact schema. No markdown, no explanation outside JSON.`;

/**
 * Classify a user query to determine routing
 * 
 * @param question - User's question
 * @param anthropic - Anthropic client instance
 * @returns Classification result with routing information
 */
export async function classifyQuery(
  question: string,
  anthropic: Anthropic
): Promise<QueryClassification> {
  console.log(`🏷️  Classifying query: "${question.substring(0, 50)}..."`);
  
  try {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 500,
      system: CLASSIFIER_SYSTEM_PROMPT,
      messages: [{
        role: "user",
        content: `Classify this aviation regulatory question:

"${question}"

Respond with JSON only:
{
  "intent": "regulatory_lookup|compliance_guidance|document_request|general_question",
  "topics": ["topic1", "topic2"],
  "cfrParts": [number],
  "cfrSections": ["part.section"],
  "documentTypes": ["AC"|"AD"|"TSO"|"Order"],
  "specificDocument": "if explicitly mentioned, e.g. AC 43.13-1B",
  "confidence": 0.0-1.0,
  "reasoning": "brief explanation",
  "needsClarification": true|false,
  "clarificationReason": "why clarification is needed (if needsClarification is true)",
  "suggestedQuestion": "what to ask the user (if needsClarification is true)"
}`
      }]
    });
    
    const content = response.content[0];
    if (content.type !== 'text') {
      console.warn('⚠️  Classifier returned non-text response');
      return DEFAULT_CLASSIFICATION;
    }
    
    // Parse JSON response
    const classification = parseClassifierResponse(content.text);
    
    console.log(`✅ Classification: intent=${classification.intent}, parts=[${classification.cfrParts}], sections=[${classification.cfrSections}], confidence=${classification.confidence}`);
    
    return classification;
    
  } catch (error) {
    console.error('❌ Classification error:', error);
    return DEFAULT_CLASSIFICATION;
  }
}

/**
 * Parse and validate classifier response
 */
function parseClassifierResponse(text: string): QueryClassification {
  try {
    // Remove any markdown code blocks if present
    let cleanText = text.trim();
    if (cleanText.startsWith('```')) {
      cleanText = cleanText.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '');
    }
    
    const parsed = JSON.parse(cleanText);
    
    // Validate and normalize the response
    return {
      intent: validateIntent(parsed.intent),
      topics: Array.isArray(parsed.topics) ? parsed.topics : [],
      cfrParts: Array.isArray(parsed.cfrParts) ? parsed.cfrParts.map(Number).filter(n => !isNaN(n)) : [],
      cfrSections: Array.isArray(parsed.cfrSections) ? parsed.cfrSections.map(String) : [],
      documentTypes: validateDocumentTypes(parsed.documentTypes),
      specificDocument: parsed.specificDocument || undefined,
      confidence: typeof parsed.confidence === 'number' ? Math.min(1, Math.max(0, parsed.confidence)) : 0.5,
      reasoning: parsed.reasoning || 'No reasoning provided',
      needsClarification: Boolean(parsed.needsClarification),
      clarificationReason: parsed.clarificationReason || undefined,
      suggestedQuestion: parsed.suggestedQuestion || undefined
    };
  } catch (error) {
    console.error('❌ Failed to parse classifier response:', error);
    console.error('   Raw response:', text.substring(0, 200));
    return DEFAULT_CLASSIFICATION;
  }
}

/**
 * Validate intent value
 */
function validateIntent(intent: string): QueryClassification['intent'] {
  const validIntents = ['regulatory_lookup', 'compliance_guidance', 'document_request', 'general_question'];
  return validIntents.includes(intent) ? intent as QueryClassification['intent'] : 'general_question';
}

/**
 * Validate document types array
 */
function validateDocumentTypes(types: unknown): QueryClassification['documentTypes'] {
  const validTypes = ['AC', 'AD', 'TSO', 'Order'];
  if (!Array.isArray(types)) return ['AC'];
  return types.filter(t => validTypes.includes(t)) as QueryClassification['documentTypes'];
}

/**
 * Quick regex-based pre-filter for obvious document requests
 * Use before LLM classifier to save API calls
 */
export function quickClassifyDocumentRequest(query: string): { isDocRequest: boolean; docType?: string; docNumber?: string } {
  const lowerQuery = query.toLowerCase();
  
  // Only trigger direct document request if user explicitly asks to "show", "get", "download", etc.
  // NOT when they reference a document in context of a question
  const isExplicitRequest = /^(show|get|download|display|find|give|what is|what does)\s/i.test(query.trim()) ||
    /\b(show me|give me|get me|find me)\b/i.test(query);
  
  // If query contains question words like "what are", "how do", "per", "according to", 
  // it's NOT a direct document request - it's a question ABOUT the document
  const isQuestion = /\b(what are|how do|how can|per |according to|based on|requirements|compliance)\b/i.test(query);
  
  if (isQuestion && !isExplicitRequest) {
    return { isDocRequest: false };
  }
  
  // AC pattern: AC 43.13-1B, AC 150/5340-30J
  const acMatch = query.match(/\bAC\s+([\d\/.-]+[A-Z]?)/i);
  if (acMatch && isExplicitRequest) {
    return { isDocRequest: true, docType: 'AC', docNumber: acMatch[1] };
  }
  
  // AD pattern: AD 2023-01-05
  const adMatch = query.match(/\bAD\s+([\d-]+)/i);
  if (adMatch && isExplicitRequest) {
    return { isDocRequest: true, docType: 'AD', docNumber: adMatch[1] };
  }
  
  // TSO pattern: TSO-C129a
  const tsoMatch = query.match(/\bTSO[-\s]?([A-Z]?\d+[A-Za-z]?)/i);
  if (tsoMatch && isExplicitRequest) {
    return { isDocRequest: true, docType: 'TSO', docNumber: tsoMatch[1] };
  }
  
  // Order pattern: Order 8900.1
  const orderMatch = query.match(/\bOrder\s+(\d+\.\d+[A-Z]?)/i);
  if (orderMatch && isExplicitRequest) {
    return { isDocRequest: true, docType: 'Order', docNumber: orderMatch[1] };
  }
  
  return { isDocRequest: false };
}
